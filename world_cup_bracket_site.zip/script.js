const teams = {
  GER:["Germany","🇩🇪"], PAR:["Paraguay","🇵🇾"], FRA:["France","🇫🇷"], SWE:["Sweden","🇸🇪"],
  RSA:["South Africa","🇿🇦"], CAN:["Canada","🇨🇦"], NED:["Netherlands","🇳🇱"], MAR:["Morocco","🇲🇦"],
  POR:["Portugal","🇵🇹"], CRO:["Croatia","🇭🇷"], ESP:["Spain","🇪🇸"], AUT:["Austria","🇦🇹"],
  USA:["United States","🇺🇸"], BIH:["Bosnia/Herz.","🇧🇦"], BEL:["Belgium","🇧🇪"], SEN:["Senegal","🇸🇳"],
  BRA:["Brazil","🇧🇷"], JPN:["Japan","🇯🇵"], CIV:["Ivory Coast","🇨🇮"], NOR:["Norway","🇳🇴"],
  MEX:["Mexico","🇲🇽"], ECU:["Ecuador","🇪🇨"], ENG:["England","ENGLAND_FLAG"], COD:["D.R. Congo","🇨🇩"],
  ARG:["Argentina","🇦🇷"], CPV:["Cape Verde","🇨🇻"], AUS:["Australia","🇦🇺"], EGY:["Egypt","🇪🇬"],
  SUI:["Switzerland","🇨🇭"], ALG:["Algeria","🇩🇿"], COL:["Colombia","🇨🇴"], GHA:["Ghana","🇬🇭"]
};

const matches = {
  r32_1:{venue:"Boston", date:"June 29", teams:["GER","PAR"], next:"r16_1"},
  r32_2:{venue:"New York", date:"June 30", teams:["FRA","SWE"], next:"r16_1"},
  r32_3:{venue:"Los Angeles", date:"June 28", teams:["RSA","CAN"], next:"r16_2"},
  r32_4:{venue:"Monterrey", date:"June 29", teams:["NED","MAR"], next:"r16_2"},
  r32_5:{venue:"Toronto", date:"July 2", teams:["POR","CRO"], next:"r16_3"},
  r32_6:{venue:"Los Angeles", date:"July 2", teams:["ESP","AUT"], next:"r16_3"},
  r32_7:{venue:"San Francisco", date:"July 1", teams:["USA","BIH"], next:"r16_4"},
  r32_8:{venue:"Seattle", date:"July 1", teams:["BEL","SEN"], next:"r16_4"},
  r32_9:{venue:"Houston", date:"June 29", teams:["BRA","JPN"], next:"r16_5"},
  r32_10:{venue:"Dallas", date:"June 30", teams:["CIV","NOR"], next:"r16_5"},
  r32_11:{venue:"Mexico City", date:"June 30", teams:["MEX","ECU"], next:"r16_6"},
  r32_12:{venue:"Atlanta", date:"July 1", teams:["ENG","COD"], next:"r16_6"},
  r32_13:{venue:"Miami", date:"July 3", teams:["ARG","CPV"], next:"r16_7"},
  r32_14:{venue:"Dallas", date:"July 3", teams:["AUS","EGY"], next:"r16_7"},
  r32_15:{venue:"Vancouver", date:"July 2", teams:["SUI","ALG"], next:"r16_8"},
  r32_16:{venue:"Kansas City", date:"July 3", teams:["COL","GHA"], next:"r16_8"},
  r16_1:{venue:"Philadelphia", date:"July 4", teams:[], next:"qf_1"},
  r16_2:{venue:"Houston", date:"July 4", teams:[], next:"qf_1"},
  r16_3:{venue:"Dallas", date:"July 6", teams:[], next:"qf_2"},
  r16_4:{venue:"Seattle", date:"July 6", teams:[], next:"qf_2"},
  r16_5:{venue:"New York", date:"July 5", teams:[], next:"qf_3"},
  r16_6:{venue:"Mexico City", date:"July 5", teams:[], next:"qf_3"},
  r16_7:{venue:"Atlanta", date:"July 7", teams:[], next:"qf_4"},
  r16_8:{venue:"Vancouver", date:"July 7", teams:[], next:"qf_4"},
  qf_1:{venue:"Boston", date:"July 9", teams:[], next:"sf_1"},
  qf_2:{venue:"Los Angeles", date:"July 10", teams:[], next:"sf_1"},
  qf_3:{venue:"Miami", date:"July 11", teams:[], next:"sf_2"},
  qf_4:{venue:"Kansas City", date:"July 11", teams:[], next:"sf_2"},
  sf_1:{venue:"Semifinal", date:"July 14", teams:[], next:"final"},
  sf_2:{venue:"Semifinal", date:"July 15", teams:[], next:"final"},
  final:{venue:"Final", date:"July 19", teams:[], next:"champion"}
};

const W=220, H=82;
const pos = {
  r32_1:[25,80], r32_2:[25,205], r32_3:[25,330], r32_4:[25,455],
  r32_5:[25,620], r32_6:[25,745], r32_7:[25,870], r32_8:[25,995],
  r16_1:[305,160], r16_2:[305,410], r16_3:[305,705], r16_4:[305,955],
  qf_1:[585,285], qf_2:[585,830],
  sf_1:[820,560],
  final:[1100,770],
  sf_2:[1380,560],
  qf_3:[1615,285], qf_4:[1615,830],
  r16_5:[1895,160], r16_6:[1895,410], r16_7:[1895,705], r16_8:[1895,955],
  r32_9:[2175,80], r32_10:[2175,205], r32_11:[2175,330], r32_12:[2175,455],
  r32_13:[2175,620], r32_14:[2175,745], r32_15:[2175,870], r32_16:[2175,995]
};

let picks = JSON.parse(localStorage.getItem("wcPicksLayered") || "{}");
let bracketName = localStorage.getItem("wcBracketName") || "";
let lastChangedNext = null;

function flagHTML(code){
  if(!code) return "";
  if(code === "ENG") return '<span class="eng-flag"></span>';
  return `<span class="flag">${teams[code][1]}</span>`;
}

function teamText(code){
  if(!code) return "";
  if(code === "ENG") return "England";
  return `${teams[code][0]} ${teams[code][1]}`;
}

function teamLabel(code){
  if(!code) return '<span class="empty">Tap prior matchup</span>';
  return `${teams[code][0]} ${flagHTML(code)}`;
}

function resetDownstream(id){
  const next = matches[id]?.next;
  if(!next) return;
  delete picks[next];
  if(matches[next]) {
    matches[next].teams = [];
    resetDownstream(next);
  }
}

function setPick(id, code){
  if(picks[id] !== code) resetDownstream(id);
  picks[id] = code;
  lastChangedNext = matches[id]?.next || null;
  localStorage.setItem("wcPicksLayered", JSON.stringify(picks));
  writeHash();
  render();
  if(id === "final") launchConfetti();
}

function deriveTeams(){
  Object.keys(matches).forEach(id => { if(!id.startsWith("r32")) matches[id].teams = []; });
  Object.entries(picks).forEach(([id, code]) => {
    const next = matches[id]?.next;
    if(next && matches[next] && !matches[next].teams.includes(code)) matches[next].teams.push(code);
  });
}

function matchHTML(id){
  const m = matches[id], opts = m.teams.slice(0,2), [x,y]=pos[id];
  let rows = "";
  for(let i=0;i<2;i++){
    const code=opts[i];
    rows += code
      ? `<button class="team ${picks[id]===code?'selected':''}" onclick="setPick('${id}','${code}')">${teamLabel(code)}</button>`
      : `<div class="slot">${teamLabel(null)}</div>`;
  }
  const classes = ["match"];
  if(picks[id]) classes.push("has-pick");
  if(lastChangedNext === id) classes.push("pop");
  return `<div class="${classes.join(" ")}" style="left:${x}px;top:${y}px"><div class="meta"><span>${m.venue}</span><span>${m.date}</span></div>${rows}</div>`;
}

function leftPoint(id){ const [x,y]=pos[id]; return [x, y+H/2]; }
function rightPoint(id){ const [x,y]=pos[id]; return [x+W, y+H/2]; }

function pathLeft(from,to){
  const [ax,ay]=rightPoint(from), [bx,by]=leftPoint(to), mx=(ax+bx)/2;
  return `<path class="connector" d="M ${ax} ${ay} L ${mx} ${ay} L ${mx} ${by} L ${bx} ${by}" />`;
}

function pathRight(from,to){
  const [ax,ay]=leftPoint(from), [bx,by]=rightPoint(to), mx=(ax+bx)/2;
  return `<path class="connector" d="M ${ax} ${ay} L ${mx} ${ay} L ${mx} ${by} L ${bx} ${by}" />`;
}

function renderLines(){
  const left = [["r32_1","r16_1"],["r32_2","r16_1"],["r32_3","r16_2"],["r32_4","r16_2"],["r32_5","r16_3"],["r32_6","r16_3"],["r32_7","r16_4"],["r32_8","r16_4"],["r16_1","qf_1"],["r16_2","qf_1"],["r16_3","qf_2"],["r16_4","qf_2"],["qf_1","sf_1"],["qf_2","sf_1"],["sf_1","final"]];
  const right = [["r32_9","r16_5"],["r32_10","r16_5"],["r32_11","r16_6"],["r32_12","r16_6"],["r32_13","r16_7"],["r32_14","r16_7"],["r32_15","r16_8"],["r32_16","r16_8"],["r16_5","qf_3"],["r16_6","qf_3"],["r16_7","qf_4"],["r16_8","qf_4"],["qf_3","sf_2"],["qf_4","sf_2"],["sf_2","final"]];
  const finalToChampion = '<path class="connector" d="M 1210 852 L 1210 980" />';
  document.getElementById("lines").innerHTML = left.map(x=>pathLeft(x[0],x[1])).join("") + right.map(x=>pathRight(x[0],x[1])).join("") + finalToChampion;
}

function formatSubtitle(){
  const stamp = new Date().toLocaleString(undefined, { year:"numeric", month:"short", day:"numeric", hour:"numeric", minute:"2-digit" });
  return `My Picks • ${stamp}`;
}

function applyBracketName(){
  const title = bracketName.trim() || "INTERACTIVE BRACKET";
  document.getElementById("bracketTitle").textContent = title;
  document.getElementById("bracketSubtitle").textContent = formatSubtitle();
}

function initNameField(){
  const input = document.getElementById("bracketNameInput");
  input.value = bracketName;
  input.addEventListener("input", function(){
    bracketName = this.value;
    localStorage.setItem("wcBracketName", bracketName);
    applyBracketName();
    writeHash();
  });
  applyBracketName();
}

function render(){
  deriveTeams();
  document.getElementById("matches").innerHTML = Object.keys(pos).map(matchHTML).join("");
  renderLines();
  document.getElementById("championName").innerHTML = picks.final ? teamLabel(picks.final) : '<span class="empty">Pick final</span>';
  document.querySelector(".champion").classList.toggle("has-pick", Boolean(picks.final));
  setTimeout(() => { lastChangedNext = null; }, 250);
}

function resetBracket(){
  picks = {};
  localStorage.removeItem("wcPicksLayered");
  writeHash();
  render();
}

function encodeState(){
  return btoa(unescape(encodeURIComponent(JSON.stringify({name: bracketName, picks}))));
}

function decodeState(value){
  try { return JSON.parse(decodeURIComponent(escape(atob(value)))); }
  catch(e){ return null; }
}

function writeHash(){
  const encoded = encodeState();
  history.replaceState(null, "", "#" + encoded);
}

function loadHash(){
  if(!location.hash || location.hash.length < 2) return;
  const state = decodeState(location.hash.slice(1));
  if(!state || typeof state !== "object") return;
  if(state.picks && typeof state.picks === "object") {
    picks = state.picks;
    localStorage.setItem("wcPicksLayered", JSON.stringify(picks));
  }
  if(typeof state.name === "string") {
    bracketName = state.name;
    localStorage.setItem("wcBracketName", bracketName);
  }
}

async function copyShareLink(){
  writeHash();
  try {
    await navigator.clipboard.writeText(location.href);
    alert("Share link copied.");
  } catch(e) {
    prompt("Copy this share link:", location.href);
  }
}

function saveBracketImage(){
  if(!picks.final){ alert("Finish the bracket first by selecting a champion."); return; }
  const canvas=document.createElement("canvas"), scale=2;
  canvas.width=2460*scale; canvas.height=1420*scale;
  const ctx=canvas.getContext("2d"); ctx.scale(scale,scale);
  const bg=ctx.createRadialGradient(1230,0,50,1230,0,1100);
  bg.addColorStop(0,"#171b23"); bg.addColorStop(1,"#050608");
  ctx.fillStyle=bg; ctx.fillRect(0,0,2460,1420);

  ctx.textAlign="center";
  ctx.font="bold 24px Arial";
  ctx.fillStyle="#22e285";
  roundRect(ctx,1115,30,230,46,23,false,true,"#22e285",3);
  ctx.fillText("WORLD CUP 2026",1230,62);

  ctx.fillStyle="#f4f5f7";
  ctx.font="900 58px Arial";
  const exportTitle = bracketName.trim() || "INTERACTIVE BRACKET";
  ctx.fillText(exportTitle,1230,132);

  ctx.fillStyle="#a9b0bb";
  ctx.font="bold 18px Arial";
  const stamp = new Date().toLocaleString(undefined, { year:"numeric", month:"short", day:"numeric", hour:"numeric", minute:"2-digit" });
  ctx.fillText("My Picks • " + stamp,1230,166);

  ctx.strokeStyle="rgba(255,255,255,.30)";
  ctx.lineWidth=2.25;
  function dl(from,to){
    const [ax,ay]=rightPoint(from), [bx,by]=leftPoint(to), mx=(ax+bx)/2;
    ctx.beginPath(); ctx.moveTo(ax,ay); ctx.lineTo(mx,ay); ctx.lineTo(mx,by); ctx.lineTo(bx,by); ctx.stroke();
  }
  function dr(from,to){
    const [ax,ay]=leftPoint(from), [bx,by]=rightPoint(to), mx=(ax+bx)/2;
    ctx.beginPath(); ctx.moveTo(ax,ay); ctx.lineTo(mx,ay); ctx.lineTo(mx,by); ctx.lineTo(bx,by); ctx.stroke();
  }
  [["r32_1","r16_1"],["r32_2","r16_1"],["r32_3","r16_2"],["r32_4","r16_2"],["r32_5","r16_3"],["r32_6","r16_3"],["r32_7","r16_4"],["r32_8","r16_4"],["r16_1","qf_1"],["r16_2","qf_1"],["r16_3","qf_2"],["r16_4","qf_2"],["qf_1","sf_1"],["qf_2","sf_1"],["sf_1","final"]].forEach(x=>dl(x[0],x[1]));
  [["r32_9","r16_5"],["r32_10","r16_5"],["r32_11","r16_6"],["r32_12","r16_6"],["r32_13","r16_7"],["r32_14","r16_7"],["r32_15","r16_8"],["r32_16","r16_8"],["r16_5","qf_3"],["r16_6","qf_3"],["r16_7","qf_4"],["r16_8","qf_4"],["qf_3","sf_2"],["qf_4","sf_2"],["sf_2","final"]].forEach(x=>dr(x[0],x[1]));
  ctx.beginPath(); ctx.moveTo(1210,852); ctx.lineTo(1210,980); ctx.stroke();

  Object.keys(pos).forEach(id=>drawMatch(ctx,id,pos[id][0],pos[id][1]));
  roundRect(ctx,1055,980,310,150,22,true,true,"#22e285",3,"rgba(34,226,133,.08)");
  ctx.textAlign="center"; ctx.fillStyle="#22e285"; ctx.font="900 18px Arial"; ctx.fillText("CHAMPION",1210,1042);
  ctx.fillStyle="#f4f5f7"; ctx.font="900 36px Arial"; ctx.fillText(teamText(picks.final),1210,1095);
  if(picks.final === "ENG") drawEnglandFlag(ctx, 1285, 1073, 34, 22);

  const link=document.createElement("a");
  const namePart = bracketName.trim() ? bracketName.trim().replace(/[^a-z0-9]+/gi,"_").replace(/^_|_$/g,"") + "_" : "";
  link.download=`${namePart}world_cup_bracket_${teams[picks.final][0].replaceAll(" ","_")}.png`;
  link.href=canvas.toDataURL("image/png"); link.click();
}

function drawMatch(ctx,id,x,y){
  const m=matches[id], opts=m.teams.slice(0,2);
  roundRect(ctx,x,y,W,H,10,true,true,picks[id]?"rgba(34,226,133,.65)":"#4b515b",picks[id]?2:1,"rgba(255,255,255,.045)");
  ctx.fillStyle="rgba(255,255,255,.055)"; ctx.fillRect(x,y,W,24);
  ctx.fillStyle="#a9b0bb"; ctx.font="bold 12px Arial"; ctx.textAlign="left"; ctx.fillText(m.venue,x+10,y+17);
  ctx.textAlign="right"; ctx.fillText(m.date,x+W-10,y+17);
  for(let i=0;i<2;i++){
    const yy=y+24+i*29, code=opts[i];
    ctx.strokeStyle="rgba(255,255,255,.09)"; ctx.beginPath(); ctx.moveTo(x,yy); ctx.lineTo(x+W,yy); ctx.stroke();
    if(picks[id]===code){ ctx.fillStyle="rgba(34,226,133,.27)"; ctx.fillRect(x+1,yy+1,W-2,28); }
    ctx.fillStyle=code?"#f4f5f7":"#747c88"; ctx.font="16px Arial"; ctx.textAlign="left";
    const label = code ? teams[code][0] : "Pending";
    ctx.fillText(label,x+10,yy+20);
    if(code==="ENG") drawEnglandFlag(ctx,x+95,yy+7,24,15);
    else if(code) ctx.fillText(teams[code][1], x+10+ctx.measureText(label).width+8, yy+20);
  }
}

function drawEnglandFlag(ctx,x,y,w,h){
  ctx.fillStyle="#fff"; ctx.fillRect(x,y,w,h);
  ctx.fillStyle="#c8102e"; ctx.fillRect(x+w*.42,y,w*.16,h); ctx.fillRect(x,y+h*.36,w,h*.28);
  ctx.strokeStyle="rgba(255,255,255,.35)"; ctx.lineWidth=1; ctx.strokeRect(x,y,w,h);
}

function roundRect(ctx,x,y,w,h,r,fill,stroke,strokeColor,lineWidth,fillColor){
  ctx.beginPath(); ctx.moveTo(x+r,y); ctx.arcTo(x+w,y,x+w,y+h,r); ctx.arcTo(x+w,y+h,x,y+h,r); ctx.arcTo(x,y+h,x,y,r); ctx.arcTo(x,y,x+w,y,r); ctx.closePath();
  if(fill){ ctx.fillStyle=fillColor||"transparent"; ctx.fill(); }
  if(stroke){ ctx.strokeStyle=strokeColor||"#000"; ctx.lineWidth=lineWidth||1; ctx.stroke(); }
}

function launchConfetti(){
  const canvas = document.getElementById("confettiCanvas");
  const ctx = canvas.getContext("2d");
  canvas.width = innerWidth; canvas.height = innerHeight;
  const pieces = Array.from({length:110}, () => ({
    x: Math.random()*canvas.width,
    y: -20-Math.random()*canvas.height*.25,
    r: 4+Math.random()*6,
    vx: -2+Math.random()*4,
    vy: 2+Math.random()*4,
    a: Math.random()*Math.PI,
    va: -.2+Math.random()*.4
  }));
  let frames = 0;
  function tick(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    pieces.forEach(p => {
      p.x += p.vx; p.y += p.vy; p.a += p.va; p.vy += .025;
      ctx.save();
      ctx.translate(p.x,p.y); ctx.rotate(p.a);
      ctx.fillStyle = Math.random() > .5 ? "#22e285" : "#f6c85f";
      ctx.fillRect(-p.r/2,-p.r/2,p.r,p.r*1.5);
      ctx.restore();
    });
    frames++;
    if(frames < 150) requestAnimationFrame(tick);
    else ctx.clearRect(0,0,canvas.width,canvas.height);
  }
  tick();
}

window.addEventListener("resize", () => {
  const canvas = document.getElementById("confettiCanvas");
  canvas.width = innerWidth; canvas.height = innerHeight;
});

document.getElementById("saveBtn").addEventListener("click", saveBracketImage);
document.getElementById("resetBtn").addEventListener("click", resetBracket);
document.getElementById("shareBtn").addEventListener("click", copyShareLink);

loadHash();
render();
initNameField();
